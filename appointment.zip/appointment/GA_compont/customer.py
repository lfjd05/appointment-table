# -*- encoding: utf-8 -*-


class Customer(object):
    """客户类"""

    def __init__(self, num=None, class_name=None):
        self.total = num                # 客户数量
        self.class_name = class_name    # 客户类别
