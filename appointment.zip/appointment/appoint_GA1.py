"""
    基因使用三维编码，三轴分别为患者id，检查项目，时间。
    该值的值为离散值0,1
"""
import numpy as np
from GA_compont.Life import Life
from pandas import read_csv, DataFrame
import random

# 参数定义
CrossRate = 0.7         # 交叉概率
MutationRate = 0.02
Population_num = 30     # 种群数量
User_Num = 3            # 客户数量
User_Classes = 13       # 客户种类


# lambda为函数简单定义式
class GA(object):
    def __init__(self, cross_rate, mutation_rate, population_num, user_num,
                 match_fun=lambda life: 1.0):
        self.user_num = user_num
        self.CrossRate = cross_rate
        self.MutationRate = mutation_rate
        self.population_num = population_num
        self.lives = []
        self.matchfun = match_fun  # 适配函数
        self.best = None  # 保存这一代中最好的个体
        self.generation = 1  # 一开始的是第一代
        self.crossCount = 0  # 一开始还没交叉过，所以交叉次数是0
        self.mutationCount = 0  # 一开始还没变异过，所以变异次数是0
        self.bounds = 0.0  # 适配值之和，用于选择时计算概率

        self.define_gene()  # 初始化种群

    def define_gene(self):
        """
            定义基因, 其中是数值代表该病人，该项目是否在该时间
            病人轴范围;A, B, C 共3
            项目轴:0-11 共12，内容见表
            时间轴:9-17 共8
        """
        for i in range(self.population_num):
            gene = []
            while True:
                gene = self.generation_gene()
                if not self.constraint(gene):
                    # 如果满足余数结束生成循环
                    break
            # print(gene)
            life = Life(gene)
            self.lives.append(life)

    def judge(self):
        """评估，计算每一个个体的适配值"""
        # 适配值之和，用于选择时计算概率
        self.bounds = 0.0
        # 假设种群中的第一个种群是最优解
        self.best = self.lives[0]
        i = 0
        for life in self.lives:
            # print('当前个体号', i)
            i += 1
            life.score = self.matchfun(life)  # 计算该种群中个体的适应度
            self.bounds += life.score
            # 如果新基因的适配值大于原先的best基因，就更新best基因
            if self.best.score < life.score:
                self.best = life

    def cross(self, parent1, parent2):
        """两点交叉"""
        index1 = random.randint(0, self.user_num - 2)  # self.user_num=3
        index2 = random.randint(index1 + 1, self.user_num - 1)
        # tempGene = parent2.gene[index1:index2]  # 交叉的基因片段
        newgene = np.empty((self.user_num, 12, 8)).astype('int')  # 交叉完毕的新基因
        for i in range(self.user_num):
            if min(index1, index2) <= i <= max(index1, index2):
                # print(newgene.shape, parent2.gene[i].shape)
                temp = np.reshape(parent2.gene[i], (1, 12, 8))
                newgene = np.append(newgene, temp, axis=0)
            else:
                temp = np.reshape(parent1.gene[i], (1, 12, 8))
                newgene = np.append(newgene, temp, axis=0)
        """单点交叉"""
        # pos1 = random.randint(1, self.user_num - 2)
        self.crossCount += 1
        newgene = newgene[-self.user_num:]
        return newgene

    def mutation(self, gene):
        """突变"""
        # 相当于取得0到self.geneLength - 1之间的一个数，包括0和self.geneLength - 1
        index1 = random.randint(0, self.user_num - 1)
        index2 = random.randint(0, self.user_num - 1)
        # 把这两个位置的城市互换
        gene[:, :, index1], gene[:, :, index2] = gene[:, :, index2], gene[:, :, index1]
        # 突变次数加1
        self.mutationCount += 1
        return gene

    def getone(self):
        """选择一个个体"""
        # 产生0到（适配值之和）之间的任何一个实数
        r = random.uniform(0, self.bounds)
        for life in self.lives:
            r -= life.score
            if r <= 0:
                return life

        raise Exception("选择错误", self.bounds)

    def newchild(self):
        """产生新后的"""
        parent1 = self.getone()
        rate = random.random()  # 产生交叉概率

        # 按概率交叉
        if rate < self.CrossRate:
            # 交叉
            parent2 = self.getone()
            gene = self.cross(parent1, parent2)
        else:
            gene = parent1.gene

        # 按概率突变
        rate = random.random()
        if rate < self.MutationRate:
            gene = self.mutation(gene)

        return Life(gene)

    def next(self):
        """产生下一代"""
        self.judge()  # 评估，计算每一个个体的适配值, 适应度最好的存入self.best
        newlives = [self.best]
        while len(newlives) < self.population_num:
            newlives.append(self.newchild())
        self.lives = newlives
        self.generation += 1

    # gene约束检查, 违反约束输出True, 没有问题输出False
    def constraint(self, gene=None):
        # 任何id中，同一个项目在任何时间只能出现一次
        # 一个病人不能同时去两个诊室
        for i in range(self.user_num):
            test_arr = gene[i, :, :]
            index = np.where(test_arr == 1)
            # print(index)
            myset = set(index[1])
            for item in myset:
                if index[1].tolist().count(item) > 1:
                    return True
        return False

    def generation_gene(self):  # 生成一个解
        gene = np.zeros((self.user_num, 12, 8)).astype('int')
        for id_index in range(self.user_num):
            if id_index == 0:  # 第一类病人
                # 该类病人需要检查的项目代码
                pro_list = [0, 2, 6]
                last_time = 0
                for pro_index in pro_list:
                    time = np.random.randint(0, 8)
                    if time == last_time:
                        gene[id_index, pro_index, np.random.randint(0, 8)] = 1
                    else:
                        gene[id_index, pro_index, time] = 1
                    last_time = time
            elif id_index == 1:  # 第二类病人
                pro_list = [0, 2, 7, 10]
                last_time = 0
                for pro_index in pro_list:
                    time = np.random.randint(0, 8)
                    if time == last_time:
                        gene[id_index, pro_index, np.random.randint(0, 8)] = 1
                    else:
                        gene[id_index, pro_index, time] = 1
                    last_time = time
            elif id_index == 2:  # 第3类病人
                pro_list = [1, 5, 8, 9, 11]
                last_time = 0
                for pro_index in pro_list:
                    time = np.random.randint(0, 8)
                    if time == last_time:
                        gene[id_index, pro_index, np.random.randint(0, 8)] = 1
                    else:
                        gene[id_index, pro_index, time] = 1
                    last_time = time
        return gene


class Table(object):
    def __init__(self):
        self.ga = GA(CrossRate, MutationRate, Population_num, User_Num, match_fun=self.matchfun())

    # 适应度函数，因为我们要从种群中挑选距离最短的，作为最优解，所以（1/距离）最长的就是我们要求的
    def matchfun(self):  # 用lambda没显得简单多少
        return lambda life: 1.0 / self.distance(life.gene)

    # 时间间隔的计算方法：2项目开始时间-1项目开始时间-1项目检查时间
    def distance(self, gene):
        """
        :param gene:个体的单个基因，1维病人id，2维度检查项目，3维度时间
        :return:
        """
        distance = 0.0
        # 3 元组，第一个元组为gene=1时的病人id, 第二个元组为gene=1时候的项目id, 第三个元组是时间
        id_num = User_Num
        for i in range(id_num):
            test_arr = gene[i, :, :]  # 每个用户单独计算id
            index = np.where(test_arr == 1)
            # print(index)
            myset = list(set(index[1]))
            for t in range(1, len(index[1])):
                diff = myset[t] - myset[t - 1]
                distance += diff
        return distance

    def run(self, n=0):
        distance = 0.0
        while n > 0:
            self.ga.next()
            distance = self.distance(self.ga.best.gene)
            print("迭代次数%d : 距离%f" % (self.ga.generation, distance))
            # print(self.ga.best.gene)
            n -= 1
        print("经过%d次迭代，最优解距离为：%f" % (self.ga.generation, distance))
        # print('最优预约表为\n', self.ga.best.gene)
        return self.ga.best.gene


def make_table(time_table):
    """
    制作预约表
    :return:
    """
    # 获取检查项目的名字
    file = read_csv('data/检查项目信息.csv', encoding='utf-8', header=0, index_col=0)
    print(file.head())
    pro_name = file.columns.values.tolist()

    table_dataframe = DataFrame(data=np.zeros((12, 8)).astype('int'), columns=['9', '10', '11', '13', '14', '15', '16',
                                                                           '17']).astype('str')
    # print(table_dataframe.head())

    user_classes = ['A', 'B', 'C']
    # 客户的预约表重合
    for i in range(User_Num):
        write_data = DataFrame(time_table[i], columns=['9', '10', '11', '13', '14', '15', '16',
                                                       '17']).replace(1, user_classes[i]).astype('str')
        table_dataframe += write_data

    table_dataframe = table_dataframe.replace(to_replace=r'0', value='', regex=True)
    table_dataframe.index = pro_name
    # 合并后的表格
    print(table_dataframe)
    table_dataframe.to_csv('预约文件表.csv')


if __name__ == '__main__':
    table = Table()
    best_table = table.run(10)
    make_table(best_table)
