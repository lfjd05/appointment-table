from pandas import read_csv, DataFrame


def read_customer_data():
    """
        读取患者的数据分类和人数，确定各个分类有多少人
    :return: 名字（按类别排序），各个类别客户数量
    """
    customer_data = read_csv('data/客户数据.csv', index_col=0)
    # customer_data = read_csv('../data/客户数据.csv', index_col=0)
    print(customer_data.shape)
    group1 = customer_data.groupby('类别')
    print(group1.sum())
    print('各个类别的客户数量\n', group1.count())   # 统计各个分组有多少客户
    a = DataFrame(group1.count()).values.tolist()
    output = []
    [output.extend(i) for i in a]
    print('找到的种类', len(output))
    name = []
    # 输出各个分组的分别都有哪些人
    for _, small_group in group1:
        name.extend(small_group['姓名'].values.tolist())
    print('客户数量', len(name))
    return name, output


# 获得各个检查项目的耗时
def fetch_time(file):
    value = file.values[0].tolist()
    # print(value)
    return value


if __name__ == '__main__':
    customer_name, _ = read_customer_data()
    print(customer_name)
