"""
    绘制甘特图,输入数据为三维best_table
"""
# -*- encoding: utf-8 -*-
import sys
sys.path.append('D:/python Programme/appointment/appointment')  # 把自己的路径加入
import matplotlib.pyplot as plt
from uint.read_customer import read_customer_data
import numpy as np


plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

# 只改变图像显示，不改变保存的png图像
# plt.rcParams['figure.figsize'] = (8.0, 4.0)
# plt.rcParams['savefig.dpi'] = 300  # 图片像素
# plt.rcParams['figure.dpi'] = 300

height = 16  # 柱体高度，设为2的整数倍，方便Y轴label居中，如果设的过大，柱体间的间距就看不到了，需要修改下面间隔为更大的值
interval = 4  # 柱体间的间隔
x_label = u"客户预约甘特图"  # 设置x轴label

time_list = ['7:00', '7:30', '8:00', '8:30', '9:00', '9:30', '10:00', '10:30', '11:00',
             '11:30', '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00',
             '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00',
             '20:30', '21:00', '21:30']
project_time = [0, 0.16, 0.5, 2, 0.33, 0.67, 5, 1, 0.16, 1]  # 时间间隔为半小时,换算 分钟数/30
project_name = ['到达', '初步看诊', '采血', 'B超', '心电图', '看结果', '采血3次', '胎心监护', '糖耐量', '留尿']
Pro_Num = 10  # 检查项目的数量一共9个   其中0不用，1看诊，5看结果永远不会选到
Time_Step = 29 - 2  # 时间步, 还需要扣除不能被赋值的第一个和最后时间点


def make_plot(table, pro_cnt):
    # 客户名字，各个类别的客户数量
    customer_name, customer_num = read_customer_data('data/客户数据.csv')
    # 客户总数
    customer_num = sum(customer_num)
    fig, ax = plt.subplots(figsize=(19, 12))    # 这个参数也关系到保存图片的大小
    plt.subplots_adjust(left=0.05, right=0.99, wspace=0.2, hspace=0.2, bottom=0.05, top=0.96)
    # fig, ax = plt.subplots(figsize=(10, 5))
    start_cnt = [0 for time_step_num in range(Time_Step)]   # 每个时间段有多少客户到达的计数
    for i in range(customer_num):
        full_table = np.zeros((Pro_Num, Time_Step + 2)).astype('int')
        full_table[:, 1:Time_Step + 1] = table[i]
        # 添加第一项和最后一项检查,1:看诊，5：看结果
        check_time = list(np.where(full_table == 1)[1])
        check_pro = list(np.where(full_table == 1)[0])  # 检查项目代码
        check_pro.insert(0, 1)
        check_pro.append(5)
        # print('该客户的检查项目', check_pro)
        first_check_time = min(check_time) - 1

        # 计算该时间有多少客户到达医院
        start_cnt[first_check_time] += 1

        last_check_time = max(check_time) + 1
        check_time.insert(0, first_check_time)
        check_time.append(last_check_time)
        # print(start_time)
        x_width = [project_time[i] for i in check_pro]
        x = list(zip(check_time, x_width))
        # print('x', x)
        # 参数柱体(x起点，x长度)，y起点，y长度
        ax.broken_barh(x, ((height+interval)*i+interval, height))
        # 设置每个柱体的注释
        text = [project_name[i] for i in check_pro]
        # print('柱体注释', check_time, text)
        for index in range(len(check_time)):
            if text[index] == 'B超':
                plt.text(check_time[index], (height + interval) * (i + 1), text[index], fontsize='small', color='red')
            else:
                plt.text(check_time[index], (height + interval) * (i + 1), text[index], fontsize='small')

    # 各个时间段到达的客户数量
    plt.text(-1, (height + interval) * customer_num+35, '到达客户')
    for time_step in range(len(start_cnt)):
        plt.text(time_step, (height + interval) * customer_num+35, start_cnt[time_step],
                 fontsize='medium', color='blue')

    # 各个时间累计的B超数量
    plt.text(-1, (height + interval) * customer_num+55, '累计B超')
    for time_step in range(1, len(pro_cnt)):
        plt.text(time_step, (height + interval) * customer_num+55, pro_cnt[time_step-1],
                 fontsize='medium', color='blue')

    # plt.title('客户预约甘特图')
    ax.set_ylim(0, (height + interval) * customer_num + interval)
    ax.set_xticks(range(0, Time_Step+2))      # 设置x刻度长度
    ax.set_xticklabels(time_list)    # 设置x刻度标记
    ax.set_xlabel(x_label)           # x轴
    ax.set_yticks(range(interval + height // 2, (height + interval) * customer_num+100, (height + interval)))
    ax.set_yticklabels(customer_name)
    ax.xaxis.grid(True)  # 只显示x轴网格
    ax.xaxis.set_ticks_position('top')
    ax.yaxis.grid(True)  # 只显示y轴网格
    # dpi 指定图像像素
    # plt.savefig('image/客户预约甘特图.png', dpi=300)  # 默认大小600*400
    plt.show()
