"""
    绘制甘特图,输入数据为三维best_table
"""
# -*- encoding: utf-8 -*-
import sys

sys.path.append('D:/python Programme/appointment/appointment')  # 把自己的路径加入
import matplotlib.pyplot as plt
from uint.read_customer import read_customer_data
import numpy as np

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

# 只改变图像显示，不改变保存的png图像
# plt.rcParams['figure.figsize'] = (8.0, 4.0)
# plt.rcParams['savefig.dpi'] = 300  # 图片像素
# plt.rcParams['figure.dpi'] = 300

height = 16  # 柱体高度，设为2的整数倍，方便Y轴label居中，如果设的过大，柱体间的间距就看不到了，需要修改下面间隔为更大的值
interval = 4  # 柱体间的间隔
x_label = u"客户预约甘特图"  # 设置x轴label

time_list = ['7:00', '7:30', '8:00', '8:30', '9:00', '9:30', '10:00', '10:30', '11:00',
             '11:30', '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00',
             '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00',
             '20:30', '21:00', '21:30']
#             空项目，问诊，采血，B超，心电图，看结果，采血3次，胎心监护，糖耐，留尿
project_time = [0, 0.16, 0.5, 0.67, 0.33, 0.67, 5, 1, 0.16, 1]  # 时间间隔为半小时,换算 分钟数/30
project_name = ['到达', '初步看诊', '采血', 'B超', '心电图', '看结果', '采血3次', '胎心监护', '糖耐量', '留尿']
Pro_Num = 10  # 检查项目的数量一共9个   其中0不用，1看诊，5看结果永远不会选到
Time_Step = 29 - 2  # 时间步, 还需要扣除不能被赋值的第一个和最后时间点


def make_plot(table, pro_cnt, cost_time):
    """
    绘制甘特图
    :param table:
    :param pro_cnt:
    :param cost_time:
    :return:
    """
    # 客户名字，各个类别的客户数量
    customer_name, customer_num = read_customer_data('data/客户数据.csv')
    # 客户总数
    customer_num = sum(customer_num)
    fig, ax = plt.subplots(figsize=(19, 12))  # 这个参数也关系到保存图片的大小
    plt.subplots_adjust(left=0.05, right=0.99, wspace=0.2, hspace=0.2, bottom=0.05, top=0.96)
    # fig, ax = plt.subplots(figsize=(10, 5))
    start_cnt = [0 for time_step_num in range(Time_Step)]  # 每个时间段有多少客户到达的计数
    pro_cnt0 = np.zeros((Pro_Num, Time_Step)).astype('int')  # 0维项目，1维度时间
    for i in range(customer_num):
        full_table = np.zeros((Pro_Num, Time_Step + 2)).astype('int')
        full_table[:, 1:Time_Step + 1] = table[i]
        # 添加第一项和最后一项检查,1:看诊，5：看结果
        check_time = list(np.where(full_table == 1)[1])
        check_pro = list(np.where(full_table == 1)[0])  # 检查项目代码
        check_pro.insert(0, 1)
        check_pro.append(5)
        # print('该客户的检查项目', check_pro)
        first_check_time = min(check_time) - 1

        # 计算该时间有多少客户到达医院
        start_cnt[first_check_time] += 1

        last_check_time = max(check_time) + 1
        # 添加第一项和最后一项检查的时间
        check_time.insert(0, first_check_time)
        check_time.append(last_check_time)

        # 考虑B超排队
        x_width = []
        index = np.where(table[i] == 1)  # 0维项目 1维时间
        pro_cnt0[index] += 1  # 各个项目已经有多少了，table的时间轴是27，它的0是full_table的1
        pice_time = 0
        for pro_index in check_pro:  # 遍历该用户所有下项目
            if pro_index == 3:  # 如果是B超
                if pro_cnt0[3, check_time[pice_time] - 1] > 2:  # 如果这个时间点B客人大于2
                    # 计算多出来几个人
                    add = project_time[pro_index] + project_time[pro_index] * (
                                pro_cnt0[3, check_time[pice_time] - 1] - 2)
                    x_width.append(add)
                else:
                    x_width.append(project_time[pro_index])
            else:
                x_width.append(project_time[pro_index])
            pice_time += 1
        # x_width = [project_time[i] for i in check_pro]   # 显示排队延迟

        # 时间管道判断，如果一个项目消耗时间过长，下个项目的时间就会延后
        last_w = 0
        last_t = -1
        new_check_time = []
        new_x_width = []
        for t, w in zip(check_time, x_width):
            new_x_width.append(w)
            if 1 < last_w <= 2:  # 上个时间和当前时间重叠就向后顺延一个
                last_t = t + 1
                new_check_time.append(t + 1)
            elif last_w > 2:     # 向后挪动2个时间步的意味下个项目也要挪动一个时间步
                last_t = t + 2
                new_check_time.append(t + 2)
            elif last_t == t:
                last_t = t + 1
                new_check_time.append(t + 1)
            else:
                last_t = t
                new_check_time.append(t)
            if w > 1:  # 如果当前项目时间超过半小时，延后下个项目的时间
                last_w = w
            else:
                last_w = 0

        x = list(zip(new_check_time, new_x_width))

        # 参数柱体(x起点，x长度)，y起点，y长度
        ax.broken_barh(x, ((height + interval) * i + interval, height))
        # 设置每个柱体的注释
        text = [project_name[i] for i in check_pro]
        # print('柱体注释', check_time, text)
        for index in range(len(new_check_time)):
            if text[index] == 'B超':
                plt.text(new_check_time[index], (height + interval) * (i + 1), text[index], fontsize='small',
                         color='red')
            else:
                plt.text(new_check_time[index], (height + interval) * (i + 1), text[index], fontsize='small')

    # 各个时间段到达的客户数量
    plt.text(-1, (height + interval) * customer_num + 35, '到达客户')
    for time_step in range(len(start_cnt)):
        plt.text(time_step, (height + interval) * customer_num + 35, start_cnt[time_step],
                 fontsize='medium', color='blue')

    # 各个时间累计的B超数量
    plt.text(-1, (height + interval) * customer_num + 55, '累计B超')
    for time_step in range(1, len(pro_cnt)):
        plt.text(time_step, (height + interval) * customer_num + 55, pro_cnt[time_step - 1],
                 fontsize='medium', color='blue')

    # 显示耗时
    plt.text(-1, (height + interval) * customer_num + 75, '耗时 %.1f小时' % cost_time)

    # plt.title('客户预约甘特图')
    ax.set_ylim(0, (height + interval) * customer_num + interval)
    ax.set_xticks(range(0, Time_Step + 2))  # 设置x刻度长度
    ax.set_xticklabels(time_list)  # 设置x刻度标记
    ax.set_xlabel(x_label)  # x轴
    ax.set_yticks(range(interval + height // 2, (height + interval) * customer_num + 100, (height + interval)))
    ax.set_yticklabels(customer_name)
    ax.xaxis.grid(True)  # 只显示x轴网格
    ax.xaxis.set_ticks_position('top')
    ax.yaxis.grid(True)  # 只显示y轴网格
    # dpi 指定图像像素
    plt.savefig('image/客户预约甘特图.png', dpi=300)  # 默认大小600*400
    plt.show()
