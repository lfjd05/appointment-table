"""
    绘制甘特图,输入数据为三维best_table
"""
# -*- encoding: utf-8 -*-
import matplotlib.pyplot as plt
from uint.read_customer import read_customer_data
import numpy as np

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

height = 16  # 柱体高度，设为2的整数倍，方便Y轴label居中，如果设的过大，柱体间的间距就看不到了，需要修改下面间隔为更大的值
interval = 4  # 柱体间的间隔
x_label = u"调度时刻"  # 设置x轴label

time_list = ['7:00', '7:30', '8:00', '8:30', '9:00', '9:30', '10:00', '10:30', '11:00',
             '11:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00',
             '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00',
             '20:30', '21:00'
             ]
Pro_Num = 10  # 检查项目的数量一共9个   其中0不用，1看诊，5看结果永远不会选到
Time_Step = 27 - 2  # 时间步, 还需要扣除不能被赋值的第一个和最后时间点


def make_plot(table):
    # 客户名字，各个类别的客户数量
    customer_name, customer_num = read_customer_data('data/客户数据.csv')
    # 客户总数
    customer_num = sum(customer_num)
    fig, ax = plt.subplots(figsize=(6, 3))
    customers_index = 0  # 客户的总人数序号
    for i in range(customer_num):
        full_table = np.zeros((Pro_Num, Time_Step + 2)).astype('int')
        full_table[:, 1:Time_Step + 1] = table[i]
        # 添加第一项和最后一项检查,1:看诊，5：看结果
        check_time = list(np.where(full_table == 1)[1])
        check_pro = list(np.where(full_table == 1)[0])  # 检查项目代码
        print('该客户的检查项目', check_pro)
        first_check_time = min(check_time) - 1
        last_check_time = max(check_time) + 1
        check_time.extend([first_check_time, last_check_time])
        start_time = [time_list[i] for i in list(check_time)]
        print(start_time)

