# -*- encoding: utf-8 -*-
"""
    分析对比数据，处理成产科预约表.csv格式
"""
from pandas import read_csv
from datetime import datetime

user_classes = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M']

customer_data = read_csv('../data/对比数据.csv', index_col=0, header=0)
print(customer_data.shape)
# print(customer_data.head())

count = 0
cost_time = 0
# 读取起止时间
for _, row in customer_data.iterrows():
    try:
        # print(row[3])
        if 11 <= int(row[3]) <= 40:   # 如果不是分类数据弃之不用
            user_name = row[0]
            start, end = datetime.strptime(row[8], '%Y/%m/%d %H:%M'), datetime.strptime(row[21], '%Y/%m/%d %H:%M')
            cost_time += (end-start).total_seconds()
            print(start)
            # print(t2s(str(start).split(' ')[-1]))
            print('患者姓名和消耗时间', count, user_name, end-start)
            count += 1
    except TypeError:
        print('读取类型错误', row[0], row[8], row[21])

print('总耗时', cost_time//3600)
