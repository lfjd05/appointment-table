"""
    患者信息的生数据读取，转化成类别信息
"""
# -*- encoding: utf-8 -*-
from pandas import read_csv, DataFrame

user_classes = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M']

# 获取检查项目的名字
file = read_csv('../data/raw_data.csv', header=0, index_col=0)
# print(file.head())
classes = file[['患者姓名', '孕周']]
# print(classes.head())

write_dataframe = DataFrame(columns=['姓名', '类别'])
for index, row in classes.iterrows():
    # 根据周判断属于哪个类别
    # print(int(row[1]))
    if 11<=int(row[1])<=13:
        write_row = DataFrame(data={'姓名': row[0], '类别': [user_classes[0]]})
        write_dataframe = write_dataframe.append(write_row, ignore_index=True)
    elif 15<=int(row[1])<=17:
        write_row = DataFrame(data={'姓名': row[0], '类别': [user_classes[1]]})
        write_dataframe = write_dataframe.append(write_row, ignore_index=True)
    elif 20<=int(row[1])<=22:
        write_row = DataFrame(data={'姓名': row[0], '类别': [user_classes[2]]})
        write_dataframe = write_dataframe.append(write_row, ignore_index=True)
    elif 24<=int(row[1])<=25:
        write_row = DataFrame(data={'姓名': row[0], '类别': [user_classes[3]]})
        write_dataframe = write_dataframe.append(write_row, ignore_index=True)
    elif 26<=int(row[1])<=28:
        write_row = DataFrame(data={'姓名': row[0], '类别': [user_classes[4]]})
        write_dataframe = write_dataframe.append(write_row, ignore_index=True)
    elif 29<=int(row[1])<=30:
        write_row = DataFrame(data={'姓名': row[0], '类别': [user_classes[5]]})
        write_dataframe = write_dataframe.append(write_row, ignore_index=True)
    elif 31<=int(row[1])<=32:
        write_row = DataFrame(data={'姓名': row[0], '类别': [user_classes[6]]})
        write_dataframe = write_dataframe.append(write_row, ignore_index=True)
    elif 33<=int(row[1])<=34:
        write_row = DataFrame(data={'姓名': row[0], '类别': [user_classes[7]]})
        write_dataframe = write_dataframe.append(write_row, ignore_index=True)
    elif 35<=int(row[1])<=36:
        write_row = DataFrame(data={'姓名': row[0], '类别': [user_classes[8]]})
        write_dataframe = write_dataframe.append(write_row, ignore_index=True)
    elif int(row[1])==37:
        write_row = DataFrame(data={'姓名': row[0], '类别': [user_classes[9]]})
        write_dataframe = write_dataframe.append(write_row, ignore_index=True)
    elif int(row[1])==38:
        write_row = DataFrame(data={'姓名': row[0], '类别': [user_classes[10]]})
        write_dataframe = write_dataframe.append(write_row, ignore_index=True)
    elif int(row[1])==39:
        write_row = DataFrame(data={'姓名': row[0], '类别': [user_classes[11]]})
        write_dataframe = write_dataframe.append(write_row, ignore_index=True)
    elif int(row[1])==40:
        write_row = DataFrame(data={'姓名': row[0], '类别': [user_classes[12]]})
        write_dataframe = write_dataframe.append(write_row, ignore_index=True)


print(write_dataframe.head(), write_dataframe.shape)
write_dataframe.to_csv('../data/客户数据.csv', encoding='utf-8-sig')
