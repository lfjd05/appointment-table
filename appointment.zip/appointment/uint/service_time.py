"""
    总消耗时间计算，因为原来的计算方式里面加入了权重，
    所以需要计算没有权重的时间消耗
"""
import numpy as np


def queue(gene=None, user_num=52, Pro_Num=0, Time_Step=0):
    """
        按照排队情况，将B超数大于2的往后延
    :param Time_Step:
    :param user_num:
    :param gene: 个体的基因
    :return:
    """
    pro_cnt = np.zeros((1, Time_Step)).astype('int')  # 0维项目，1维度时间

    b_mode_info = gene[:, 3, :]   # 0轴客户，1轴时间
    user_id = np.where(b_mode_info == 1)[0]  # 有B超的客户
    for i in b_mode_info:   # 遍历客户
        index = np.where(i == 1)   # 有B超的客户id和时间
        pro_cnt[0, index] += 1  # 在某个时间点已经有多少了
    b_mode_time = np.where(pro_cnt > 2)[1]   # 大于2的时间

    cnt = 0  # 这个位置的第3个病人才往后推时间
    for user in user_id:  # 遍历所有有B超客户
        for time in b_mode_time:
            if gene[user, 3, time] == 1:   # 如果这个病人这个时候看了B超
                cnt += 1
                if cnt > 2:             # 看B超人数大于2
                    # 寻找后面的时间有没有能安排B超的空闲时间
                    free_time = list(set(range(Time_Step))-set(np.where(gene[:, 3, :] == 1)[1]))
                    free_time = [x for x in free_time if x > time]
                    gene[user, 3, [time, free_time[0]]] = gene[user, 3, [free_time[0], time]]  # B 超时间交换
                    cnt = 0
    return gene


def cost_service_time(table, pro_num, time_step):
    """
        计算最佳迭代表的总耗时
    :param table: 最佳迭代安排表
    :param pro_num: 全部检查项目的数量
    :param time_step: 总计的时间步长
    :return:
    """
    pro_cnt = np.zeros((pro_num, time_step)).astype('int')  # 每个项目在每个时间点已经有多少人了 0维项目，1维度时间
    user_num = table.shape[0]
    cost_time = 0.0
    # table = queue(table, user_num, pro_num, time_step)
    for i in table:
        index = np.where(i == 1)
        pro_cnt[index] += 1  # 累计某项目在某个时间点已经有多少客户了
        myset = list(set(index[1]))  # 获得所有看诊时间点
        start = min(myset)
        end = max(myset)
        diff = abs(end-start)
        cost_time += diff
    cost_time = cost_time * 0.5 + 0.8 * user_num + 0.67 * user_num    # 看结果还消耗了0.67小时
    print('%d 个客户总耗时:%.2f' % (user_num, cost_time))
    # 考虑B超排队
    b_mode_num = pro_cnt[3, :]  # B超的数量
    for time in range(time_step):
        if b_mode_num[time] > 1:  # 注意B超有两个
            cost_time += (b_mode_num[time]-2) * 0.67
    print('%d 个客户总耗时(考虑排队):%.2fh' % (user_num, cost_time))

    return b_mode_num, cost_time, table
