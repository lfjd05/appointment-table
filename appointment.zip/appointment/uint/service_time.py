"""
    总消耗时间计算，因为原来的计算方式里面加入了权重，
    所以需要计算没有权重的时间消耗
"""
import numpy as np


def cost_service_time(table, pro_num, time_step):
    """
        计算最佳迭代表的总耗时
    :param table: 最佳迭代安排表
    :param pro_num: 全部检查项目的数量
    :param time_step: 总计的时间步长
    :return:
    """
    pro_cnt = np.zeros((pro_num, time_step)).astype('int')  # 每个项目在每个时间点已经有多少人了 0维项目，1维度时间
    user_num = table.shape[0]
    cost_time = 0.0
    for i in table:
        index = np.where(i == 1)
        pro_cnt[index] += 1  # 累计某项目在某个时间点已经有多少客户了
        myset = list(set(index[1]))  # 获得所有看诊时间点
        start = min(myset)
        end = max(myset)
        diff = abs(end-start)
        cost_time += diff
    cost_time = cost_time + 1 * user_num
    print('%d 个客户总耗时:%.2f' % (user_num, cost_time))
    b_mode_num = pro_cnt[3, :]     # B超的数量
    return b_mode_num
