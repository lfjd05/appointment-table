"""
    总消耗时间计算，因为原来的计算方式里面加入了权重，
    所以需要计算没有权重的时间消耗
"""
import numpy as np


def cost_service_time(table):
    user_num = table.shape[0]
    cost_time = 0.0
    for i in table:
        index = np.where(i == 1)
        myset = list(set(index[1]))  # 获得所有看诊时间点
        start = min(myset)
        end = max(myset)
        diff = abs(end-start)
        cost_time += diff
    print('%d 个客户总耗时:%.2f' % (user_num, cost_time))
