"""
    将实际数据画成甘特图
"""
from pandas import read_csv, DataFrame, merge
from datetime import datetime

# 读取两个待筛选文件
file1 = read_csv('../data/对比数据.csv', index_col=0, header=0)   # 含有时间的文件
file2 = read_csv('../data/客户数据.csv', index_col=0)   # 含有客户类别的数据

print(file1.head(), file2.head())
print(file1.shape, file2.shape)
customer_data = merge(file1, file2, how='right', on='姓名')
# 删除重复
customer_data = customer_data.drop_duplicates(['VISIT_NO'])
# 按类别分组
customer_data = customer_data.sort_values('类别')
print(customer_data.head())
print('筛选合并后数据', customer_data.shape)    # 莉莉有重名，只依靠姓名合并会重复
# customer_data.to_csv('合并后的数据.csv', encoding='utf-8-sig')

count = 0
cost_time = 0
# 读取起止时间
for _, row in customer_data.iterrows():
    try:
        if 11 <= int(row[3]) <= 40:   # 如果不是分类数据弃之不用
            user_name = row[0]
            start, end = datetime.strptime(row[8], '%Y/%m/%d %H:%M'), datetime.strptime(row[21], '%Y/%m/%d %H:%M')
            cost_time += (end-start).total_seconds()
            start = datetime.strptime(str(start).split(' ')[-1], '%H:%M:%S')
            # start = str(start).split(' ')[-1]
            print(start)
            # print(t2s(str(start).split(' ')[-1]))
            count += 1
    except TypeError:
        print(row[0], row[8], row[21])
