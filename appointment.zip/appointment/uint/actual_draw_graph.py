"""
    将实际数据画成甘特图
"""
import sys
sys.path.append('D:/python Programme/appointment/appointment')  # 把自己的路径加入
from pandas import read_csv, merge
from datetime import datetime
import matplotlib.pyplot as plt
from uint.time_convert import t2s
import numpy as np

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

height = 16  # 柱体高度，设为2的整数倍，方便Y轴label居中，如果设的过大，柱体间的间距就看不到了，需要修改下面间隔为更大的值
interval = 4  # 柱体间的间隔
x_label = u"客户预约甘特图"  # 设置x轴label

time_list = ['7:00:00', '7:30:00', '8:00:00', '8:30:00', '9:00:00', '9:30:00', '10:00:00', '10:30:00', '11:00:00',
             '11:30:00', '13:00:00', '13:30:00', '14:00', '14:30', '15:00', '15:30', '16:00',
             '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00',
             '20:30', '21:00', '21:30', '22:00']
project_time = [0, 0.16, 0.5, 1, 0.33, 0.67, 5, 1, 0.16, 1]  # 时间间隔为半小时,换算 分钟数/30
project_name = ['到达', '初步看诊', '采血', 'B超', '心电图', '看结果', '采血3次', '胎心监护', '糖耐量', '留尿']
Pro_Num = 10  # 检查项目的数量一共9个   其中0不用，1看诊，5看结果永远不会选到
Time_Step = [t2s('7:00:00'), t2s('22:00:00')]  # 时间步, 还需要扣除不能被赋值的第一个和最后时间点

# 读取两个待筛选文件
file1 = read_csv('../data/对比数据.csv', index_col=0, header=0)   # 含有时间的文件
file2 = read_csv('../data/客户数据.csv', index_col=0)   # 含有客户类别的数据

# print(file1.head(), file2.head())
# print(file1.shape, file2.shape)
customer_data = merge(file1, file2, how='right', on='姓名')
# 删除重复
customer_data = customer_data.drop_duplicates(['VISIT_NO'])
# 按类别分组
customer_data = customer_data.sort_values('类别', ascending=False).reset_index(drop=True)
# print(customer_data.head())
print('筛选合并后数据', customer_data.shape)    # 莉莉有重名，只依靠姓名合并会重复
# customer_data.to_csv('合并后的数据.csv', encoding='utf-8-sig')

cost_time = 0
fig, ax = plt.subplots(figsize=(19, 12))  # 这个参数也关系到保存图片的大小
plt.subplots_adjust(left=0.05, right=0.99, wspace=0.2, hspace=0.2, bottom=0.05, top=0.96)
# 读取起止时间
for i, row in customer_data.iterrows():
    if 11 <= int(row[3]) <= 40:   # 如果不是分类数据弃之不用
        user_name = row[0]
        start, end = datetime.strptime(row[8], '%Y/%m/%d %H:%M'), datetime.strptime(row[21], '%Y/%m/%d %H:%M')
        cost_time = (end-start).total_seconds()    # 持续时间
        start = datetime.strftime(start, '%H:%M:%S')   # 开始时间
        start = t2s(start)
        # start = str(start).split(' ')[-1]
        # print(start)
        x = [(start, cost_time)]
        print('柱体坐标', x)
        # 参数柱体x起点，x长度，y起点，y长度
        ax.broken_barh(x, ((height + interval) * i + interval, height))

print(Time_Step)
ax.set_ylim(0, (height + interval) * customer_data.shape[0] + interval)
ax.set_xticks(range(Time_Step[0], Time_Step[1], 1800))  # 设置x刻度长度
x_len = [i for i in range(Time_Step[0], Time_Step[1], 1800)]
print('刻度长度',x_len)
print([t2s(i) for i in time_list])
ax.set_xticklabels(time_list)  # 设置x刻度标记
ax.set_xlabel(x_label)
ax.set_yticks(range(interval + height // 2, (height + interval) * customer_data.shape[0], (height + interval)))
ax.set_yticklabels(customer_data['姓名'])
# ax.grid(True) # 显示网格
ax.xaxis.grid(True)  # 只显示x轴网格
ax.xaxis.set_ticks_position('top')
ax.yaxis.grid(True)  # 只显示y轴网格
# dpi 指定图像像素
# plt.savefig('客户预约甘特图.png', dpi=300)  # 默认大小600*400
plt.show()
