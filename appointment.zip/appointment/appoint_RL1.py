# -*- encoding: utf-8 -*-
"""
    强化学习算法：
    思想：类似围棋布阵，把各个棋子放在最优的位置上
Action: 棋盘上的检查项目向左或者向右移动
State: 棋盘的状态，既一次动作执行完毕后的棋盘
Reward：一场结束后预约表总耗时+B超科室负载情况的倒数，耗时越长reward越小

"""

import numpy as np
import pandas as pd
from RL_compont.env import Table
from RL_compont.Q_learning import Q_learningTable


# 更新
def update():
    observation = 0
    for episode in range(100):
        # initial observation
        observation = 0

        done = 0
        while True:
            # RL choose action based on observation
            action = RL.choose_action(str(observation))

            # RL take action and get next observation and reward
            observation_, reward = env.get_env_feedback(observation, action)

            # RL learn from this transition
            RL.learn(str(observation), action, reward, str(observation_))

            # swap observation
            observation = observation_

            done += 1
            env.update_env(observation, episode, done + 1, reward)  # 环境更新
            # break while loop when end of this episode
            if done == 1000:
                break
    return observation


if __name__ == "__main__":
    env = Table()
    RL = Q_learningTable(actions=list(range(env.n_action)))
    result = update()
