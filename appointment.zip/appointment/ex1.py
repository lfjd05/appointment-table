import numpy as np
import random

gene = np.arange(96).reshape((6,2,8))
print(gene)
index1 = random.randint(0, 8 - 1)
index2 = random.randint(0, 8 - 1)
print('交换的位置', index1, index2)
# 把这两个位置的时间互换
# gene[:, :, index1], gene[:, :, index2] = gene[:, :, index2], gene[:, :, index1]
gene[:, :, [index1, index2]] = gene[:, :, [index2, index1]]
print('突变完毕后\n', gene)

