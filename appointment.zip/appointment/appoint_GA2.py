# -*- encoding: utf-8 -*-
"""
    基因使用三维编码，三轴分别为患者id，检查项目，时间。
    该值的值为离散值0,1
"""
import numpy as np
from GA_compont.Life import Life
from GA_compont.customer import Customer
from pandas import read_csv, DataFrame
import random
from uint.read_customer import read_customer_data, fetch_time

# 参数定义
CrossRate = 0.7  # 交叉概率
MutationRate = 0.02  # 突变概率
Population_num = 80  # 种群数量
Pro_Num = 10  # 检查项目的数量一共9个   其中0不用，1看诊，5看结果永远不会选到
Time_Step = 27 - 2  # 时间步, 还需要扣除不能被赋值的第一个和最后时间点

user_classes = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M']
Project = [[2, 3, 4], [2], [2, 3], [6, 8], [2, 3], [9], [2, 4], [2, 3, 7], [2, 7], [3], [7], [7], [2, 3, 7]]
# 客户名字，各个类别的客户数量
customer_name, customer_num = read_customer_data()
User_Num = sum(customer_num)  # 客户数量
User_Classes = len(user_classes)  # 客户种类


# lambda为函数简单定义式
class GA(object):
    def __init__(self, cross_rate, mutation_rate, population_num, user_num,
                 match_fun=lambda life: 1.0):
        self.user_num = user_num  # 客户数量
        self.CrossRate = cross_rate
        self.MutationRate = mutation_rate
        self.population_num = population_num
        self.lives = []
        self.matchfun = match_fun  # 适配函数
        self.best = None  # 保存这一代中最好的个体
        self.generation = 1  # 一开始的是第一代
        self.crossCount = 0  # 一开始还没交叉过，所以交叉次数是0
        self.mutationCount = 0  # 一开始还没变异过，所以变异次数是0
        self.bounds = 0.0  # 适配值之和，用于选择时计算概率

        self.define_gene()  # 初始化种群

    def define_gene(self):
        """
            定义基因, 其中是数值代表该病人，该项目是否在该时间
            病人轴范围;A, B, C.... 共13
            项目轴:0-5 共6，内容见表
            时间轴:9-17 半小时间隔共17
        """
        for i in range(self.population_num):
            while True:
                gene = self.generation_gene()
                if not self.constraint(gene):
                    # 如果满足余数结束生成循环
                    break
            # print(gene)
            life = Life(gene)
            self.lives.append(life)

    def judge(self):
        """评估，计算每一个个体的适配值"""
        # 适配值之和，用于选择时计算概率
        self.bounds = 0.0
        # 假设种群中的第一个种群是最优解
        self.best = self.lives[0]
        i = 0
        for life in self.lives:
            # print('当前个体号', i)
            i += 1
            life.score = self.matchfun(life)  # 计算该种群中个体的适应度
            # print('该个体的适应度', life.score)
            self.bounds += life.score
            # 如果新基因的适配值大于原先的best基因，就更新best基因
            if self.best.score < life.score:
                if not self.constraint(life.gene):  # 如果最好个体没有违反约束
                    self.best = life

    def cross(self, parent1, parent2):
        """两点交叉"""
        newgene = np.empty((self.user_num, Pro_Num, Time_Step)).astype('int')  # 交叉完毕的新基因
        """
        index1 = random.randint(0, self.user_num - 2)  # self.user_num=3
        index2 = random.randint(index1 + 1, self.user_num - 1)
        # tempGene = parent2.gene[index1:index2]  # 交叉的基因片段
        for i in range(self.user_num):
            if min(index1, index2) <= i <= max(index1, index2):
                # print(newgene.shape, parent2.gene[i].shape)
                temp = np.reshape(parent2.gene[i], (1, Pro_Num, Time_Step))
                newgene = np.append(newgene, temp, axis=0)
            else:
                temp = np.reshape(parent1.gene[i], (1, Pro_Num, Time_Step))
                newgene = np.append(newgene, temp, axis=0)
        """
        """单点交叉
            如果交叉点在时间轴会出现一个项目可能有两个时间点
            如果交叉点在项目轴会出现一个时间点病人查两个项目
            所以只能加约束判断或者在病人id轴
        """
        copint = np.random.randint(0, len(parent1.gene) // 2)
        # print(newgene.shape, parent2.gene[i].shape)
        temp = np.concatenate((parent1.gene[:copint], parent2.gene[copint:]), axis=0)
        newgene = np.append(newgene, temp, axis=0)
        # pos1 = random.randint(1, self.user_num - 2)
        self.crossCount += 1
        newgene = newgene[-self.user_num:]
        return newgene

    def mutation(self, gene):
        """突变"""
        # mut_times = 10
        # while mut_times > 10:
        # 相当于取得0到self.geneLength - 1之间的一个数，包括0和self.geneLength - 1
        index1 = random.randint(0, Time_Step - 1)
        index2 = random.randint(0, Time_Step - 1)
        # 把这两个位置的时间互换
        gene[:, :, [index1, index2]] = gene[:, :, [index2, index1]]
        if self.constraint(gene):
            print('突变后约束违反')
        # 突变次数加1
        self.mutationCount += 1
        return gene

    def getone(self):
        """选择一个个体"""
        # 产生0到（适配值之和）之间的任何一个实数
        r = random.uniform(0, self.bounds)
        for life in self.lives:
            r -= life.score
            if r <= 0:
                return life

        raise Exception("选择错误", self.bounds)

    def newchild(self):
        """产生新后的"""
        parent1 = self.getone()
        rate = random.random()  # 产生交叉概率

        # 按概率交叉
        if rate < self.CrossRate:
            # 交叉
            parent2 = self.getone()
            if self.constraint(parent1.gene) or self.constraint(parent2.gene):
                print('重组前约束违反')
            gene = self.cross(parent1, parent2)
        else:
            gene = parent1.gene
        if self.constraint(gene):
            print('重组后约束违反')

        # 按概率突变
        rate = random.random()
        if rate < self.MutationRate:
            if self.constraint(gene):
                print('突变前约束违反')
            gene = self.mutation(gene)
        return Life(gene)

    def next(self):
        """产生下一代"""
        self.judge()  # 评估，计算每一个个体的适配值, 适应度最好的存入self.best
        newlives = [self.best]
        while len(newlives) < self.population_num:
            newlives.append(self.newchild())
        self.lives = newlives
        self.generation += 1

    # gene约束检查, 违反约束输出True, 没有问题输出False
    def constraint(self, gene=None):
        # 约束1：任何id中，同一个项目在任何时间只能出现一次（生成的时候可以解决）
        # 约束2：一个病人不能同时去两个诊室
        # 约束3：只有最后一个检查项目（看检查结果）能安排在最后一个时间步（生成的时候可以解决）
        # 约束4：只有第一个检查项目（问诊）能安排在该病人第一个时间步（生成的时候可以解决）
        for i in range(self.user_num):
            test_arr = gene[i, :, :]
            index = np.where(test_arr == 1)
            if len(index[1]):  # 判断test_arr是不是有空的
                myset = set(index[1])  # 获取所有项目的时间
                myset1 = set(index[0])  # 获取所有项目
                for item in myset:
                    if index[1].tolist().count(item) > 1:  # 如果一个时间有1个以上的项目
                        print('一个时间有1个以上的项目')
                        return True
                for item1 in myset1:
                    if index[0].tolist().count(item1) > 1:  # 如果一个项目查了两次
                        print('一个项目查了两次')
                        return True
            else:
                print('当前user为空', i)
                return True
        return False

    def generation_gene(self):  # 生成一个解
        """
        :return:
        """
        # 定义客户, 变量中包含了客户的类别和数量
        total_customer_num = 0  # 总共的客户数量
        customers = define_customer()
        gene = np.zeros((self.user_num, Pro_Num, Time_Step)).astype('int')
        for i, customers_class in enumerate(customers):
            for id_index in range(customers_class.total):  # 该类别客户数量
                if customers_class.class_name == user_classes[i]:  # 判断病人类
                    # 该类病人需要检查的项目代码
                    pro_list = Project[i]
                    last_time = 0
                    for pro_index in pro_list:
                        if 5 <= last_time <= Time_Step - 5:  # 时间赋值不要太远
                            time = np.random.randint(last_time - 5, last_time + 5)  # 给该项目随机安排一个时间
                        elif 0 < last_time < 5:
                            time = np.random.randint(0, last_time + 5)
                        elif Time_Step - 5 < last_time < Time_Step:
                            time = np.random.randint(last_time - 5, Time_Step)  # 给该项目随机安排一个时间
                        else:  # last_time=0时赋值随机
                            time = np.random.randint(0, Time_Step)  # 给该项目随机安排一个时间
                        # 不限制远距离赋值的时候
                        # time = np.random.randint(0, Time_Step)
                        if time == last_time:
                            gene[total_customer_num, pro_index, np.random.randint(0, Time_Step)] = 1
                        else:
                            gene[total_customer_num, pro_index, time] = 1
                        last_time = time
                total_customer_num += 1
        # print(gene)
        # print('基因大小', gene.shape)
        return gene


class Table(object):
    def __init__(self, file):
        self.file = file
        self.ga = GA(CrossRate, MutationRate, Population_num, User_Num, match_fun=self.matchfun())

    # 适应度函数，因为我们要从种群中挑选距离最短的，作为最优解，所以（1/距离）最长的就是我们要求的
    def matchfun(self):  # 用lambda没显得简单多少
        return lambda life: 1.0 / self.distance(life.gene) + 1.0 / self.focus(life.gene)  # 加权求和得适应
        # return lambda life: 1.0 / self.distance(life.gene)
        # return lambda life: 1.0 / (self.distance(life.gene) + self.focus(life.gene))/2
    
    # 时间间隔的计算方法：2项目开始时间-1项目开始时间-1项目检查时间
    def distance(self, gene):
        """
        :param gene:个体的单个基因，1维病人id，2维度检查项目，3维度时间
        :return:
        """
        # 获取距离权值
        cost_time = fetch_time(self.file)
        distance = 0.0
        # 3 元组，第一个元组为gene=1时的病人id, 第二个元组为gene=1时候的项目id, 第三个元组是时间
        id_num = User_Num  # 用户总数
        for i in range(id_num):
            test_arr = gene[i, :, :]  # 每个用户单独计算id
            index = np.where(test_arr == 1)
            # print(index)
            myset = list(set(index[1]))
            for t in range(1, len(index[1])):
                diff = abs(myset[t] - myset[t - 1] + cost_time[t - 1])
                # diff = abs(myset[t] - myset[t - 1])
                distance += diff
        return distance

    def focus(self, gene):
        """
            计算各个项目的集中度
        :param gene:个体的单个基因，1维病人id，2维度检查项目，3维度时间
        :return:
        """
        focus_value_sum = 0.0
        pro_num = Pro_Num  # 检查项目总数
        for i in range(pro_num):
            test_arr = gene[:, i, :]  # 按项目遍历, 0轴为客人id 纵轴为时间点
            index = np.where(test_arr == 1)
            user_sum = len(index[0])            # 该项目有多少客人
            time_sum = len(list(set(index[1])))  # 该项目用了多少时间点，两个相同的时间点算一个时间点
            if time_sum == 0:
                focus_value = 0
            else:
                focus_value = user_sum / time_sum
            focus_value_sum += focus_value
        return focus_value_sum*10

    def run(self, n=0):
        distance = 0.0
        focus = 0.0
        while n > 0:
            self.ga.next()
            distance, focus = self.distance(self.ga.best.gene), self.focus(self.ga.best.gene)
            print("迭代次数%d : 距离%f, 集中度%f, 最佳适应度 %.5f" % (self.ga.generation, distance, focus, self.ga.best.score))
            n -= 1
        print("经过%d次迭代，最优解距离为：%f, 最优集中度%f" % (self.ga.generation, distance, focus))
        # print('最优预约表为\n', self.ga.best.gene)
        correction_time(distance)
        self.ga.constraint(self.ga.best.gene)
        return self.ga.best.gene


def make_table(time_table, file):
    """
    制作预约表
    :return:
    """
    # print(file.head())
    pro_name = file.columns.values.tolist()

    table_dataframe = DataFrame(data=np.zeros((Pro_Num, Time_Step + 2)).astype('int'),
                                columns=['7:00', '7:30', '8:00', '8:30', '9:00', '9:30', '10:00', '10:30', '11:00',
                                         '11:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00',
                                         '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00',
                                         '20:30', '21:00'
                                         ]).astype('str')

    # 客户的预约表重合
    customers = define_customer()  # 返回各个类别的客户数
    customers_index = 0  # 客户的总人数序号
    for i, customers_class in enumerate(customers):  # 13个类别的客人
        for id_index in range(customers_class.total):  # 该类别客户数量
            full_table = np.zeros((Pro_Num, Time_Step + 2)).astype('int')  # 包含第一和最后时间点的大表
            # a = np.where(time_table[customers_index]==1)
            # if not len(a[1]):
            #     print('当前a为空')
            full_table[:, 1:Time_Step + 1] = time_table[customers_index]
            # 添加第一项和最后一项检查,1:看诊，5：看结果
            check_time = np.where(full_table == 1)
            first_check_time = min(check_time[1]) - 1
            full_table[1, first_check_time] = 1
            # print(min(check_time[1]))
            last_check_time = max(np.where(full_table == 1)[1]) + 1
            full_table[5, last_check_time] = 1

            write_data = DataFrame(full_table,
                                   columns=['7:00', '7:30', '8:00', '8:30', '9:00', '9:30', '10:00', '10:30', '11:00',
                                            '11:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00',
                                            '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00',
                                            '20:30', '21:00'
                                            ])
            write_data = write_data.replace(1, '({})'.format(customers_class.class_name) +
                                            '{}'.format(customer_name[customers_index]) + '/').astype('str')
            table_dataframe += write_data
            customers_index += 1

    table_dataframe = table_dataframe.replace(to_replace=r'0', value='', regex=True)  # 正则表达式匹配消去所有的0
    table_dataframe.index = pro_name
    table_dataframe.index.name = '环节'  # 索引名字
    table_dataframe = table_dataframe[1:]
    table_dataframe = table_dataframe.T
    # 合并后的表格
    # print(table_dataframe.head())
    table_dataframe.to_csv('产科预约表.csv', encoding='utf-8-sig')


def define_customer():
    """
        定义客户
    :return:
    """
    customer_info = []
    for i in range(User_Classes):
        customer_info.append(Customer(customer_num[i], user_classes[i]))
    # print(len(customer_info))
    return customer_info


def correction_time(dis_time):
    # 挂号时间到录入体征时间之间的时间差
    # 换算小时
    cost_time = dis_time * 0.5 + 1.5 * User_Num
    print('总耗时为（hours）', cost_time)


if __name__ == '__main__':
    # 获取检查项目的名字
    File = read_csv('data/产检项目信息.csv', encoding='utf-8', header=0, index_col=0)
    table = Table(File)
    best_table = table.run(150)
    make_table(best_table, File)
