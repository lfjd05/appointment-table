# -*- encoding: utf-8 -*-
"""
    定义环境，环境即预约安排表
"""
import numpy as np
import pandas as pd
from uint.read_customer import fetch_time
import time

pro_name = {'A': ['采血', 'B超', '心电图'], 'B': ['采血'], 'C': ['采血', 'B超'],
          'D': ['采血3次', '胎心监护'], 'E': ['采血', 'B超'], 'F': ['留尿'],
          'G': ['采血', '心电图'], 'H': ['采血', 'B超', '胎心监护'],
          'I': ['采血', '胎心监护'], 'J': ['B超'], 'K': ['胎心监护'], 'L': ['胎心监护'],
          'M': ['采血', 'B超', '胎心监护']}
Project = [[2, 3, 4], [2], [2, 3], [6, 8], [2, 3], [9], [2, 4], [2, 3, 7], [2, 7], [3], [7], [7], [2, 3, 7]]
Time_Step = 29 - 2  # 时间步, 还需要扣除不能被赋值的第一个和最后时间点
Pro_Num = 10  # 检查项目的数量一共9个   其中0不用，1看诊，5看结果永远不会选到
MaxState = 3
FRESH_TIME = 0.31  # 每个动作执行时间

# 客户名字，各个类别的客户数量
user_classes = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M']
# customer_name, customer_num = read_customer_data()
# User_Num = sum(customer_num)  # 客户数量
# User_Classes = len(user_classes)  # 客户种类

# 显示相关的参数
UNIT = 40   # pixels
MAZE_H = 4  # grid height
MAZE_W = 4  # grid width


def build_table():
    """
    创建环境，即预约表
    :return:
    """
    file = pd.read_csv('data/客户数据.csv', header=0, index_col=0)
    print('客户数据的大小', file.shape)
    env = np.zeros((file.shape[0], Time_Step)).astype('int')
    customer_info = []
    # 对env表格随机赋值
    for index, i in file.iterrows():
        customer_info.append(Customer(index=index, name=i['姓名'], classes=i['类别']))
        # 获得客户类别的项目
        pro_list = Project[i['类别']]
        time = np.random.choice(range(0, Time_Step-10), len(pro_list), replace=False)
        env[index, time] = pro_list
    return env, customer_info


# 时间间隔的计算方法：2项目开始时间-1项目开始时间-1项目检查时间
def distance(gene):
    """
    :param gene:个体的单个基因，1维病人id，2维度检查项目，3维度时间
    :return:
    """
    # 获取项目耗时权值
    file = pd.read_csv('data/产检项目信息.csv', encoding='utf-8', header=0, index_col=0)
    cost_time = fetch_time(file)
    # 时间安排权值（初始时间越晚权值越大）
    weight = [15, 22, 32, 42, 80]
    distance = 0.0
    # 3 元组，第一个元组为gene=1时的病人id, 第二个元组为gene=1时候的项目id, 第三个元组是时间
    id_num = len(gene)  # 用户总数
    pro_cnt = np.zeros((Pro_Num, Time_Step)).astype('int')  # 每个项目在每个时间点已经有多少人了 0维项目，1维度时间
    for i in range(id_num):
        test_arr = gene[i, :]     # 第i个用户
        index = np.where(test_arr != 0)  # 这个人的所有时间点
        # print(index)
        pro_cnt[index] += 1  # 累计某项目在某个时间点已经有多少客户了
        myset = list(set(index[0]))  # 获得所有看诊时间点
        for t in range(1, len(index[0])):  # 遍历时间点的数量
            if 11 < myset[t] <= 15:
                diff1 = abs(myset[t] - myset[t - 1] - cost_time[t - 1] + weight[0])
            elif 15 < myset[t] <= 20:
                diff1 = abs(myset[t] - myset[t - 1] - cost_time[t - 1] + weight[1])
            elif 20 < myset[t] <= 25:
                diff1 = abs(myset[t] - myset[t - 1] - cost_time[t - 1] + weight[2])
            elif 25 < myset[t] <= 27:
                diff1 = abs(myset[t] - myset[t - 1] - cost_time[t - 1] + weight[3])
            elif 27 < myset[t]:
                diff1 = abs(myset[t] - myset[t - 1] - cost_time[t - 1] + weight[4])
            else:
                diff1 = abs(myset[t] - myset[t - 1] - cost_time[t - 1])

            # 考虑B超的排队 排队时间等于等待时间*前面排队人数
            distance += 6 * pro_cnt[3, myset[t]] + diff1
    return distance


class Customer(object):
    def __init__(self, index, name, classes):
        """
        :param index: 该顾客的编号
        :param classes: 该顾客属于的类别
        """
        self.index = index
        self.name = name
        self.classes = classes


class Table(object):
    """
        创建环境
    """
    def __init__(self):
        self.action_space = ['突变', '交叉']
        self.n_action = len(self.action_space)
        self.title = 'table'
        self.env, self.customer = build_table()

    def get_env_feedback(self, state, action):
        """
        得到环境的反馈量，只有所有状态完了才计算reward
        :param state:     状态：每个客户的检查时间点数量（客户，项目数量）
        :param action:     动作：每个客户检查项目（客户，项目名字）
        :return:
        """

        if action == '交叉':
            state_ = self.cross(state)
            R = 1./distance(state)
        elif action == '突变':
            state_ = self.mutation(state)
            R = 1./distance(state)
        else:
            state_ = 0
            R = 0
        return state_, R

    def cross(self, parent1):
        """单点交叉
            随机在病人代号维度设一个随机数n,以n为切分点，交换parent1,parent2两部分
            一个gene相当于state
        """
        parent2, _ = build_table()
        # newgene = np.empty((parent1.shape[0], Time_Step)).astype('int')  # 交叉完毕的新基因
        copint = np.random.randint(0, len(parent1) // 2)      # 交叉点

        newgene = np.concatenate((parent1[:copint], parent2[copint:]), axis=0)
        print(newgene.shape)
        return newgene

    def mutation(self, gene):
        """突变
            随机交换gene的两列
        """
        # 相当于取得0到self.geneLength - 1之间的一个数，包括0和self.geneLength - 1
        index1 = np.random.randint(0, Time_Step - 1)
        index2 = np.random.randint(0, Time_Step - 1)
        # 把这两个位置的时间互换
        gene[:, :, [index1, index2]] = gene[:, :, [index2, index1]]
        return gene

    def update_env(self, state, episode, step_counter, reward):
        """
        # 创建环境，只负责显示，和算法本身无关
        :param step_counter: 经历了多少state
        :param reward: 当前state获得的奖励
        :param state: 当前状态
        :param episode: 当前场数
        :return:
        """
        if state == 'terminal':
            interaction = 'Episode %s: total_steps= %s' % (episode + 1, step_counter)
            print('\r{}'.format(interaction), end='')
            time.sleep(2)
            print('\r      ', end='')  # 覆盖上一行的显示
        else:
            interaction = 'Reward is %f' % reward
            print('\r{}'.format(interaction))
            time.sleep(FRESH_TIME)
