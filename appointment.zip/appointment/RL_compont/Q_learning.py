import numpy as np
import pandas as pd


class Q_learningTable(object):
    """
        Q表的主要方法，建立表，选择动作，更新q值，添加新state
    """

    def __init__(self, actions, learning_rate=0.01, reward_decay=0.9, e_greedy=0.9):
        self.actions = actions  # a list
        self.lr = learning_rate  # 学习率
        self.gamma = reward_decay  # 奖励衰减
        self.epsilon = e_greedy  # 贪婪度
        self.q_table = pd.DataFrame(columns=self.actions, dtype=np.float64)  # 初始 q_table

    def choose_action(self, observation):
        """
            选择a，输入s上的观测值
        """
        self.check_state_exist(observation)  # 检测本 state 是否在 q_table 中存在(见后面标题内容)

        state_action = self.q_table.iloc[int(observation), :]
        # 选择 action
        if (np.random.uniform() < self.epsilon) and (state_action.all() != 0):  # 选择 Q value 最高的 action
            state_action = self.q_table.loc[observation, :]  # state几个动作的q value

            # 同一个 state, 可能会有多个相同的 Q value, 所以我们乱序一下
            action = np.random.choice(state_action[state_action == np.max(state_action)].index)  # index 返回标签

        else:  # 刚初始化空表时，随机选择 action
            action = np.random.choice(self.actions)
        return action

    def learn(self, s, a, r, s_):
        """
            更新Q值
        """
        self.check_state_exist(s_)  # 检测 q_table 中是否存在 s_ (见后面标题内容)
        q_predict = self.q_table.loc[s, a]
        if s_ != 'terminal':
            q_target = r + self.gamma * self.q_table.loc[s_, :].max()  # 下个 state 不是 终止符
        else:
            q_target = r  # 下个 state 是终止符
        self.q_table.loc[s, a] += self.lr * (q_target - q_predict)  # 更新对应的 state-action 值

    def check_state_exist(self, state):
        """
        当我们不知道有多少state的时候需要用
        检测q_table中有没有这个state,如果没有就插入全0state
        :param state:
        :return:
        """
        if state not in self.q_table.index:
            # append new state to q table
            a = pd.Series(
                    [0] * len(self.actions),
                    index=self.q_table.columns,
                    name=state,)
            self.q_table = self.q_table.append(
                pd.Series(
                    [0] * len(self.actions),
                    index=self.q_table.columns,
                    name=state,
                ))
