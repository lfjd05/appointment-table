from pandas import read_csv
import numpy as np
import math
# 导入种群和内置算子相关类
from gaft import GAEngine
from gaft.components import BinaryIndividual, Population
from gaft.operators import RouletteWheelSelection, UniformCrossover, FlipBitMutation
# Analysis plugin base class.
from gaft.plugin_interfaces.analysis import OnTheFlyAnalysis
# 内置的存档适应度函数的分析类
from gaft.analysis.fitness_store import FitnessStore

city_data = read_csv('data/city.txt', header=None, index_col=None)
print(city_data.head())

# 参数定义
CrossRate = 0.7  # 交叉概率
MutationRate = 0.02
population_num = 20
GeneLength = len(city_data)   # 基因长度

# 计算距离矩阵
# i从-1到最后一个城市,-1是倒数第一个
distance = []
for i in range(0, len(city_data)):
    for j in range(0, len(city_data)):
        index1, index2 = i, j
        city1, city2 = city_data.ix[index1], city_data.ix[index2]
        x1, x2 = city1[1], city2[1]
        y1, y2 = city1[2], city2[2]
        distance.append(math.sqrt((city1[1] - city2[1]) ** 2 + (city1[2] - city2[2]) ** 2))
print('距离矩阵大小', len(distance))
print(distance)
dis_array = np.array(distance)
dis_array = dis_array.reshape((GeneLength, GeneLength))


# 定义基因
gen = range(GeneLength)   # 生成基因序列
# range为解的数值范围，二进制位数为(0+genelength)/esp后再看占多少位2进制数。esp参数为精度
indv_template = BinaryIndividual(ranges=[(0, GeneLength)], eps=0.01)  # 个体+基因
# 定义种群
population = Population(indv_template=indv_template, size=population_num)
population.init()  # Initialize population with individuals.

# 定义算子
# Use built-in operators here.
selection = RouletteWheelSelection()
crossover = UniformCrossover(pc=0.8, pe=0.5)   # pc发生交叉互换可能性，pe基因交换可能性
mutation = FlipBitMutation(pm=0.1)  # 突变可能性

# 算法引擎
engine = GAEngine(population=population, selection=selection,
                  crossover=crossover, mutation=mutation,
                  analysis=[FitnessStore])


# 适应度函数，求最小
@engine.fitness_register
@engine.minimize
def fitness(indv):
    x, = indv.solution
    x = int(x)
    distance = 0.0
    # i从-1到最后一个城市,-1是倒数第一个
    for i in range(-1, len(city_data)-1):
        index1, index2 = x, x+1
        city1, city2 = city_data.ix[index1], city_data.ix[index2]
        distance += math.sqrt((city1[1] - city2[1]) ** 2 + (city1[2] - city2[2]) ** 2)
    return distance


@engine.analysis_register
class ConsoleOutput(OnTheFlyAnalysis):
    master_only = True
    interval = 1

    def register_step(self, g, population, engine):
        msg = 'Generation: {}, best fitness: {:.3f}'.format(g, engine.fmax)
        engine.logger.info(msg)

    def finalize(self, population, engine):
        best_indv = population.best_indv(engine.fitness)
        x = best_indv.solution
        y = engine.ori_fmax
        msg = 'Optimal solution: ({}, {})'.format(x, y)
        self.logger.info(msg)


if '__main__' == __name__:
    engine.run(ng=100)
